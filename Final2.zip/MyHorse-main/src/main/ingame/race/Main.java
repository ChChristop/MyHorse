package main.ingame.race;

public class Main {
	
	public Main() {
		Ingame g = new Ingame();
		g.run();
		
	}
	
}