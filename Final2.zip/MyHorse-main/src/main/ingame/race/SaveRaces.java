package main.ingame.race;

import java.util.ArrayList;

import main.ingame.horse.Horses;

public class SaveRaces{
	
	//저장소
	//각 회차 경주마들/결과
	ArrayList<ArrayList<Horses>> result = new ArrayList<>();
	
	
	public ArrayList<ArrayList<Horses>> getResult(){
		return this.result;
	}
	public void setResult(ArrayList<ArrayList<Horses>> result) {
		this.result =result;
	}
	
	public void print() {
		for(ArrayList<Horses> stall : this.result) {
			for(Horses horse : stall) {
				System.out.println(horse.getName());
				System.out.println(horse.getRank());
				System.out.println(horse.getLine());
			}
		}
	}
	
	//각 회 경기 결과 저장 메서드
	public void save(ArrayList<Horses> raceHorses) {
		result.add(raceHorses);

	}
}
