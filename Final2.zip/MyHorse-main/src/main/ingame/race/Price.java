package main.ingame.race;


import java.util.Scanner;
import main.ingame.horse.Horses;
/*게임 보상	
 * 상금받기(말주인)	
 * 배팅금 받기(배팅자 수)	
 * 말에게 경험치 부여		
*/
interface Get{
	
	void victoryPrice();
	void afterGameExp();
	
}

public class Price implements Get{
	
	
	Scanner sc = new Scanner(System.in);
	Horses h = new Horses();

	//1등 상금받기(말주인)
	public void victoryPrice() {
		for(Horses rh : h.getRaceHorses()) {
			if(rh.getRank()==1) {
				System.out.println(rh.getLine()+" " + rh.getName() + ": 상금 1000$를 획득하셨습니다.");
			}else
				System.out.println(rh.getLine()+" " + rh.getName() + ": 다음 기회를 노려보세요.");
			}
	}
	

	//말에게 경험치 주기
	//1-3등일때만 경험치 추가
	public void afterGameExp() {
		Horses m = h.getRaceHorses().get(0);
		switch(m.getRank()) {
			case 1:
				m.addExp(30);
				break;
			case 2:
				m.addExp(20);
				break;
			case 3:
				m.addExp(10);
				break;
			default:
				if(m.getExp()>10)
				m.addExp(-10);
				break;
		}
	}

	
}
