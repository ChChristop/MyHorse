package main.ingame.horse;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Horses {
	
	Scanner sc = new Scanner(System.in);
	
	//내말
	ArrayList<Horses> horses = new ArrayList<Horses>();

	//경주마들
	ArrayList<Horses> raceHorses = new ArrayList<Horses>();

	
	//말 세부정보
	String name;
	String color;
	double speed;
	int stamina;		
	String levelOfUpbringing;
	String raceType;
	int level;		
	int exp;
	int condition;
	String sympathetic;
	String line;
	int rank = 1;
	//경기장 길이
	int fieldLength = 2500;
	//생성자
	public Horses() {
		
	}
	public Horses(String name, String color, double speed, int stamina,String lu, String raceType, int level, int exp, int condition, String sympathetic, 
			int rank,String line) {
		this.name = name;
		this.color = color;
		this.speed = speed;
		this.stamina = stamina;
		this.levelOfUpbringing = lu;
		this.raceType = raceType;
		this.level = level;
		this.exp = exp;
		this.condition	= condition;
		this.sympathetic = sympathetic;
		this.rank = rank;
		this.line = line;
	}

	public Horses(String name, String color) {
		this.name = name;
		this.color = color;
		this.speed = 100;
		this.stamina = 100;
		this.levelOfUpbringing = "-";
		this.raceType = "잠금";
		this.level = 1;
		this.exp = 0;
		this.condition	= 100;
		this.sympathetic = "중";
		this.rank = 0;
		this.line = "미정";
	}
	
	//경주마 생성자
	public Horses(String name, double speed, String color) {
		this.name = name;
		this.color = color;
		this.speed = speed;
		this.stamina = 100;
		this.raceType = "잠금";
		this.level = 20;
		this.rank = 0;
		this.line = "미정";
	}
	public ArrayList<Horses> getRaceHorses() {
		return raceHorses;
	}

	public void setRaceHorses(ArrayList<Horses> raceHorses) {
		this.raceHorses = raceHorses;
	}
	public int getRank() {
		return this.rank;
	}
	public void setRank(int r) {
		this.rank = r;
	}
	
	public int getFieldLength() {
		return this.fieldLength;
	}
	public void gsetFieldLength(int field) {
		this.fieldLength = field;
	}
	
	//내 말들 보관함(용량 2) 받아오기
	public ArrayList<Horses> getMyHorses(){
		return this.horses;
	}
	
	// getter&setter
	public String getLine() {
		return this.line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return this.color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	public void addExp(int a) {
		this.exp = this.exp + a; 
	}
	public int getLevel() {
		return this.level;
	}
	public void addLevel(int level) {
		this.level = this.level+ level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public double getSpeed() {
		return this.speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public void addSpeed(double speed) {
		this.speed = this.speed +speed;
	}
	public int getStamina() {
		return this.stamina;
	}
	public void setStamina(int stamina) {
		this.stamina = stamina;
	}
	public void addStamina(int stamina) {
		this.stamina = this.stamina + stamina;
	}
	public String getLevelOfUpbringing() {
		return this.levelOfUpbringing;
	}
	public void setLevelOfUpbringing(String levelOfUpbringing) {
		this.levelOfUpbringing = levelOfUpbringing;
	}
	public String getRaceType() {
		return this.raceType;
	}
	public void setRaceType(String raceType) {
		this.raceType = raceType;
	}
	public int getCondition() {
		return this.condition;
	}
	public void addCondition(int a) {
		this.condition = this.condition + a;
	}
	public void setCondition(int condition) {
		this.condition = condition;
	}	
	public String getSympathetic() {
		return this.sympathetic;
	}
	public void setSympathetic(String sympathetic) {
		this.sympathetic = sympathetic;
	}
	

	//말들 생성  & 경주말에 넣기
	public void createRaceHorses() {
		raceHorses.add(0,new Horses("", 0, ""));
		raceHorses.add(1,new Horses("얼룩이", 70, "검정"));
		raceHorses.add(2,new Horses("파랑이", 75, "무지개"));
		raceHorses.add(3,new Horses("금박이", 80, "빨강"));
		raceHorses.add(4,new Horses("분홍이", 73, "파랑"));
		raceHorses.add(5,new Horses("초록이", 78, "초록"));
		raceHorses.add(6,new Horses("금금이", 88, "황금"));
		raceHorses.add(7,new Horses("말말이", 83, "갈색"));
		
	}
	//랜덤 수 생성 1~8 // 임시로 2
	public int[] createRandomNumber() {
		int count = raceHorses.size(); // 난수 생성 갯수
		
		int a[] = new int[count];
		Random r = new Random();
		
		for(int i=0; i<count; i++){
			a[i] = r.nextInt(raceHorses.size()) + 1; // 1 ~ 8까지의 난수 
			for(int j=0; j<i; j++){
				if(a[i] == a[j]){
					i--;
				}
			}
		}
		return a;
	}
	
	//레인에 랜덤배정
	public void giveLine() {
		//랜덤한 line
		int randNum[] = createRandomNumber();
	
		for(int i = 0; i<raceHorses.size(); i++) {
			//랜덤한 라인에 배치
			raceHorses.get(i).setLine("["+randNum[i]+"번라인]");
			
		}
	}

	//내말 전체조회(1~8)
	public void print() {
		for(Horses horse : horses) {
			System.out.println("이름: " + horse.getName());
			System.out.println("색상: " + horse.getColor());
			System.out.println("속도: " + horse.getSpeed());
			System.out.println("체력: " + horse.getStamina());
			System.out.println("육성난이도: " + horse.getLevelOfUpbringing());
			System.out.println("주행타입: " + horse.getRaceType());
			System.out.println("레벨: " + horse.getLevel());
			System.out.println("경험치: " + horse.getExp());
			System.out.println("컨디션: " + horse.conditionLevel(horse));
			System.out.println("교감도: " + horse.getSympathetic());;
		}
		System.out.println();
	}
	//경주말 전체조회(1~8)
	public void printRaceHorse() {
		
		for(Horses horse :this.raceHorses) {
			System.out.println("이름: " + horse.getName());
			System.out.println("색상: " + horse.getColor());
			System.out.println("속도: " + horse.getSpeed());
			System.out.println("체력: " + horse.getStamina());
			System.out.println("주행타입: " + horse.getRaceType());
			System.out.println("레벨: " + horse.getLevel());
			System.out.println("라인 번호: " + horse.getLine());
			System.out.println();
		}
		
		System.out.println();
	}
	
	
	public int createRandomNumber2() {
		int a;
		Random r = new Random();
		a = r.nextInt(7) + 1; // 1 ~ 7까지의 난수 
		return a;
	}
	
	
	public void getRaceTime(Horses rh) {
		String fieldStone[] = new String[40];	
		//현재 거리
		int count = 0;
		int mass = 0;
		int oneStep = fieldLength/40;	// 2500/40 = 62.5 = 1칸 정보
		int stone = 0; 	//현재 위치 정보
		System.out.println();
		while(stone < 40) {
			for(int j = 0 ; j<40; j++) {
				if(stone == j ) 
				fieldStone[stone] = ">";
				else
				fieldStone[j] = "_ ";
			}
			System.out.println(rh.getName()+ ": "+ String.join("", fieldStone));
			mass = (int) (count * rh.getSpeed());
			stone = mass/oneStep;
			count++;// _ 40개
			
			try {
				Thread.sleep(80);
			} catch (InterruptedException e) {}
			
		}
		rh.setRank(this.rank);
		this.rank++;	
	
	}
	
	
	//랭크 출력
	public void printAllRank() {
		int count = 1;
		for(Horses horse : this.raceHorses) {
			System.out.println(horse.getLine() +" "+count + "번마: "+ horse.getName() +" 순위: " + horse.getRank());
			count++;
		}
		System.out.println("=============================================================================");
		System.out.println();
	}

//	말 객체 생성(name, color)
	public void createHorse() {
		String n ;
		String c;
		
		if(this.horses.isEmpty()) {
			System.out.println("말에게 이름을 주세요: ");
			n = sc.nextLine();
			System.out.println("색상을 정해주세요:");
			c = sc.nextLine();
			horses.add(new Horses(n, c));
			
			System.out.println("========축하합니다 [" + horses.get(0).getName() + "]가 생성되었습니다!========");
			print();
			System.out.println("===================================================");
		}else {
			System.out.println("이미 키우고 있는 말이 있습니다.");
		}
		System.out.println();
	}
		
//	this.name = name;
//	this.color = color;
//	this.speed = 100;
//	this.stamina = 100;
//	this.levelOfUpbringing = "-";
//	this.raceType = "잠금";
//	this.level = 1;
//	this.exp = 0;
//	this.condition	= 100;
//	this.sympathetic = "중";
//	this.rank = 0;
//	this.line = "미정";
	//내말 생성 & 경주마에 추가
	public void addToRaceHorses() {
		
			this.raceHorses.remove(0);
			this.raceHorses.add(0,this.horses.get(0));
		
}	
	public void addToMyHorses() {
		Horses h = new Horses(raceHorses.get(0).getName(),raceHorses.get(0).getColor(),raceHorses.get(0).getSpeed(),
				raceHorses.get(0).getStamina(),raceHorses.get(0).getLevelOfUpbringing(), raceHorses.get(0).getRaceType(),
				raceHorses.get(0).getLevel(),raceHorses.get(0).getExp(),raceHorses.get(0).getCondition(),raceHorses.get(0).getSympathetic(),
				raceHorses.get(0).getRank(),raceHorses.get(0).getLine());
		
		this.horses.add(0,h);
	
}	
	
	//말 컨디션과 (컨디션 포인트,체력, 교감도)의 관계
	public String conditionLevel(Horses h) {
		
		if(h.getSympathetic() == "상") {
			h.addCondition(10);
		}else if (h.getSympathetic()  == "중") {
			h.addCondition(5);
		}else
			h.addCondition(-10);
		
		if(h.getStamina()>= 80) {
			h.addCondition(10);;
		}else if(h.getStamina() < 80 && h.getStamina() >40) {
			h.addCondition(5);
		}
		else {
			h.addCondition(-10);
		}
		
		
		if(h.getCondition()> 80) {
			return "상";
		}else if(h.getCondition() <= 80 && h.getCondition() >40) {
			return "중";
		}
		else {
			return "하";
		}
	}
	
}
