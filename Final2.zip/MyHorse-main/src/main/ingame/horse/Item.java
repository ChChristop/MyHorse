package main.ingame.horse;

public class Item {
	
	Horses h = new Horses();
	UpBringing u = new UpBringing();
	
	public void useSpeedItem() {
		h.getMyHorses().get(0).addSpeed(10);
	}
	
	public void useStaminaItem() {
		h.getMyHorses().get(0).addStamina(20);
	} 


	public void useAttackItem() {
		int a = h.createRandomNumber2();
		h.getRaceHorses().get(a).addSpeed(-20);
		
	}
	
	public void useExpItem() {
		h.getMyHorses().get(0).addExp(100); 
		u.levelUp(h);
		
	}	
}
