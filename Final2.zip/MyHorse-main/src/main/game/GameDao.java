package main.game;

import java.util.ArrayList;
import main.ingame.horse.Horses;
import main.ingame.race.SaveRaces;

public class GameDao {
	SaveRaces sr = new SaveRaces();
	Horses h = new Horses();
	
	ArrayList<ArrayList<Horses>> resultDao = sr.getResult();
	ArrayList<Horses> stallDao = h.getRaceHorses();
	int field = h.getFieldLength();
			
	public void setResultDao(ArrayList<ArrayList<Horses>> result) {
		this.resultDao =result ;
	}
	public ArrayList<ArrayList<Horses>> getResultDao(){
		return this.resultDao;
	}
	//경주말 8마리
	public ArrayList<Horses> getStallDao(){
		return this.stallDao;
	}
	public void setStallDao(ArrayList<Horses> stall) {
		this.stallDao = stall;
	}
	
	public int getField() {
		return this.field;
	}
	public void setField(int field) {
		this.field = field;
	}

	public void print(ArrayList<ArrayList<Horses>> resultDao) {
		for(ArrayList<Horses> race :resultDao ) {
			for(Horses horse : race) {
				System.out.print("이름: " + horse.getName());
				System.out.print("순위: " + horse.getRank() + "위" );
				System.out.println(horse.getLine());
			}
		}
		
	}
	
	
}
