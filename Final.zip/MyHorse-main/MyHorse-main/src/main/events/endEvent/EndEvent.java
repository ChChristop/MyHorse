package main.events.endEvent;

public class EndEvent {
	EndEvent(){
		System.out.println("	종료된 이벤트 목록");
	}
}
