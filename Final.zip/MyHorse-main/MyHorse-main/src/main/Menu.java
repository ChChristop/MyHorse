package main;

public class Menu extends Frame {
	public static void main(String[] args) {
		Frame frame = new Frame();
		frame.run();
	}
}
